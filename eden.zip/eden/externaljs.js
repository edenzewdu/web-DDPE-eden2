﻿
function msg(){
alert("Click on the Submit button after filling all information required");}